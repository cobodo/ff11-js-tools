require 'nkf'
require "template"
require 'win32/registry'


class WordDictionary
    @@path = ""
    @@item_dic = nil
    @@text_dic = nil

    def self.register_dir(path)
        @@path = path if path != ""
    end

    def initialize(path = "")
        @@path = path if path != ""
        return if @@item_dic != nil && @@text_dic != nil
        file = nil
        begin
            file = open("item_dic.db", "r")
            @@item_dic = Marshal.load(file)
            file.close
            file = open("text_dic.db", "r")
            @@text_dic = Marshal.load(file)
            file.close
        rescue
            p $!
        end
    end

    def getWord(text)
        return @@text_dic[text[2..3]] if text[0] == 2
        return @@text_dic[text[2..3]] if text[0] == 4
        return @@item_dic[text[2..3]] if text[0] == 7
        return @@item_dic[text[2].chr + "\0"] if (text[0] == 10 && text[3] == 255)
    end
end

class CharacterProfile
    @@word_dic = nil

    def self.register_dic(wd)
        @@word_dic = wd if wd != nil
    end

    def initialize(path = "", wd = nil)
        @path = path if path != ""
        @@word_dic = wd if wd != nil
    end

    def line2str(line)
        #終端null除去
        line.gsub!(/\x00/) {""}
        #辞書単語を文字列変換
        #print line, "\n"
        fl = false
        line.gsub!(/\xfd(.{4})\xfd/m) do
            w = @@word_dic.getWord($1)
            if !w then
                printf("   error: %02x%02x%02x%02x => %s\n", $1[0], $1[1], $1[2], $1[3], w)
                fl = true
            end
            w
        end
        fl = fl | line.match(/\0/)
        if fl then
            printf("   line: %s\n", line)
        end
        return NKF.nkf("-S -w8", line)
    end

    def analyzeMacroFile(file)
        # header読み捨て
        ##固定ヘッダ 01 00 00 00
        #header = file.read(4) or return false
        ##不明な4byte
        #header = file.read(4) or return false
        ##MD5
        #header = file.read(16) or return false
        header = file.read(24)

        macros = []

        for i in 0..19
            printf("  macro%d:\n", i)
            file.read(4) or return false # 4byte読み捨て(00 00 00 00)
            lines = []
            for l in 0..5
                lines[l] = file.read(60) or return false
                lines[l] = line2str(lines[l])
                file.read(1) or return false # 終端null
            end
            name = file.read(8) or return false
            name = line2str(name)
            name = " " if name == ""
            file.read(2) or return false
            macros[i] = {'name' => name, 'lines' => lines}
        end

        return macros # [{'name' => name, 'lines' => [line, 0..5]}, 0..19]
    end

    def getMacroSet(book, set)
        num = ""
        num = book.to_s if book != 0
        num += set.to_s
        num = "" if num == "0"
        mcr_fn = "mcr" + num + ".dat"
        file = nil
        macros = []
        begin
            file = open(@path + mcr_fn, "r")
            file.binmode
            printf("book%d:\n set%d:\n", book, set)
            macros = analyzeMacroFile(file)
        rescue Errno::ENOENT
            #p $!
            # templateのためにカラの構造を作っておく
            #for i in 0..19
            #    macros[i] = {'name' => ' ', 'lines' => nil}
            #    lines = []
            #    for j in 0..5
            #        lines[j] = ''
            #    end
            #    macros[i]['lines'] = lines
            #end
        else
            file.close
        end

        return macros
    end

    def makeHTML(outfn)
        return false if FileTest.exist?(outfn) && !FileTest.writable?(outfn)

        # マクロ集合作成
        books = []
        for book in 0..19
            books[book] = []
            for set in 0..9
                cur_set = getMacroSet(book, set)
                books[book][set] = cur_set if cur_set
            end
        end

        # get Book titles
        titles = []
        file = nil
        begin
            file = open(@path + "mcr.ttl")
            # header読み捨て
            file.read(24)
            for i in 0..19
                line = file.read(16) or return false
                titles[i] = line2str(line)
            end
        rescue Errno::ENOENT
            p $!
        else
            file.close
        end

        # templateから出力GET→書き出し
        v = Template.get("macro.tpl", false)
        v.books = books
        v.titles = titles
        begin
            file = open(outfn, "w")
            file.write(v.show(false))
        rescue Errno::ENOENT
            p $!
        else
            file.close
        end

        return true
    end
end

install_dir = Win32::Registry::HKEY_LOCAL_MACHINE.open('SOFTWARE\PlayOnline\InstallFolder')['0001']
install_dir += "\\" if install_dir !~ /\\$/
install_dir.gsub!(/\\/, "/").gsub(/^c/, "C")

ids = Dir.entries(install_dir + 'USER\\')[2..-1]

wd = WordDictionary.new(install_dir)
CharacterProfile.register_dic(wd)

ids.each do |id|
    CharacterProfile.new(install_dir + "USER/" + id + "/").makeHTML(id + ".html")
end
