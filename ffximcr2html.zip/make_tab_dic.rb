def read_item (f)
    file = nil
    item_dic = {}
    begin
        file = open(f, "r")
        first = ''
        second = ''
        while l = file.gets
            next if l =~ /^[^\d]/
            if l =~ /^(\d+)=<<(.*)>>$/ then
                id = $1.to_i
                first = (id / 256).chr
                #first = first.gsub(/\\/) {'\\\\'}
                #first = first.gsub(/\'/) {"\\\'"}
                second = (id % 256).chr
                #second = second.gsub(/\\/) {'\\\\'}
                #second = second.gsub(/\'/) {"\\\'"}
                #index = eval("'"+first+second+"'")
                index = first+second
                item_dic[index] = $2
            end
        end
    rescue Errno::ENOENT
        p $!
    else
        file.close
    end
    item_dic
end

def read_text (f)
    file = nil
    text_dic = {}
    begin
        file = open(f, "r")
        first = ''
        second = ''
        while l = file.gets
            next if l =~ /^;/
            if l =~ /^\[(\d+)\]/ then
                first = $1.to_i.chr
                next
            end
            if l =~ /^(\d+)=<<(.*)>>$/ then
                second = $1.to_i.chr
                #index = eval("'"+first+second+"'")
                index = first+second
                text_dic[index] = $2
            end
        end
    rescue Errno::ENOENT
        p $!
    else
        file.close
    end
    text_dic
end

item_dic = read_item("item")
item_dic = item_dic.update(read_item("item2"))
text_dic = read_text("text")
text_dic = text_dic.update(read_text("text2"))

p item_dic.length
p text_dic.length

file = nil
begin
    file = open("item_dic.db", "w")
    Marshal.dump(item_dic, file)
    file.close
    file = open("text_dic.db", "w")
    Marshal.dump(text_dic, file)
    file.close
rescue
    p $!
end
