FFXI マクロHTML化スクリプト

■概要
FFXIのマクロをHTML形式で閲覧可能にするRubyスクリプト

■必要なもの
ActiveScriptRuby1.8。
開発は1.8.7で行った。

■同梱したファイル
- readme.txt
    このファイル
- ffximcr2html.rb
    スクリプト本体
- template.rb
    本体から利用する外部スクリプト
    以下のURLのものを利用しました
    http://0-oo.net/sbox/ruby-etude/40lines-template-engine
- macro.tpl
    ファイル出力する際のテンプレートファイル
    変更すれば任意の形式で出力できる
- make_tab_dic.rb
    item, item2, text, text2 をバイナリ形式に変換する

■使用方法
1. FFXIMCR (http://www.geocities.jp/FFXi621/) から、Items.zip と Text.zip をダウンロードし、中から
    text
    text2
    item
    item2
の4ファイルを取り出して同じフォルダの中に入れる。

2. ruby で make_tab_dic.rb を実行する。
　item_dic.db と、text_dic.db が作られる。

3. ruby で ffximcr2html.rb を実行する。
　実行すると、キャラクタidごとにHTMLファイルができる。このidはキャラクタ固有であるが、名前などとは関係なく決定されるようだ。
　どのキャラクタがどのidに該当するのかは内容などから推測するしかない（と思う）。

